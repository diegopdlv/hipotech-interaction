import importlib.resources as pkg_resources
import hipotech_analysis
from pathlib import Path


def get_template_html(
    html_template_path: str,
) -> str:
    """Returns the HTML template as a string from the specified path relative to the project.
    
    Args:
        html_template_path (str): The path to the HTML template file.
        
    Returns:
        str: The HTML template as a string.
    """
    with pkg_resources.files(hipotech_analysis).joinpath(html_template_path).open("r", encoding="utf-8") as f:
        template_html = f.read()

    return template_html


def make_path_relative_to_project(
    input_path: str,
)-> str:
    """Make a path relative to the project root.
    
    Args:
        input_path (str): The path to make relative.
        
    Returns:
        str: The relative path.
    """
    relative_path = pkg_resources.files(hipotech_analysis).joinpath(input_path)

    return relative_path


def get_template_html_from_path(
    html_template_path: str,
) -> str:
    """Returns the HTML template as a string from the specified path.
    
    Args:
        html_template_path (str): The path to the HTML template file.
        
    Returns:
        str: The HTML template as a string.
    """
    with html_template_path.open("r", encoding="utf-8") as f:
        template_html = f.read()

    return template_html


def adjust_resource_paths(
    html: str, 
    html_file_path: Path
) -> str:
    """Adjusts the resource paths in the HTML content to be absolute file paths relative to the html template.
    
    Args:
        html (str): The HTML content as a string.
        html_file_path (Path): The path to the HTML file, used to determine the base path for resources.
    
    Returns:
        str: The HTML content with adjusted resource paths.
    """
    base_path = html_file_path.parent.resolve()

    html = html.replace('href="../formatting/', f'href="file://{base_path}/formatting/')
    html = html.replace('src="../images/', f'src="file://{base_path}/images/')
    return html

def get_relative_html_template(
    template_path: str,  
) -> str:
    """Returns the HTML template as a string, with paths adjusted to be relative to the project root.
    
    Args:
        template_path (str): The path to the HTML template file.
        
    Returns:
        str: The HTML template with adjusted resource paths.
    """
    
    template_path = make_path_relative_to_project(template_path)

    # Read the HTML template
    html_template = get_template_html_from_path(
        html_template_path=template_path,
    )

    html_template = adjust_resource_paths(
        html=html_template, 
        html_file_path=template_path
    )
    
    return html_template
