from pdf_parser.utils import SectionHeader

# Define the list of section headers used to split the PDF.
EQUIFAX_FILE_HEADER_NAMES: list[SectionHeader] = [
    SectionHeader('Sabio Empresarial'),
    SectionHeader('Consulta Rápida'),
    SectionHeader('Información General'),
    SectionHeader('Datos Generales'),
    SectionHeader('Datos Principales'),
    SectionHeader('Otros Reportes Negativos'),
    SectionHeader('Detalle Variación'),
    SectionHeader('Posición Histórica'),
    SectionHeader('Gráficos'),
    SectionHeader('Reporte de Vencidos'),
    SectionHeader('Reporte SBS/Microfinanzas'),
    SectionHeader('Reporte SBS/Microfinanzas por entidades'),
    SectionHeader('Aval/Codeudor'),
    SectionHeader('Es Avalista de:'),
    SectionHeader('Quiénes lo Avalan:'),
    SectionHeader('Documentos Protestados como Deudor/Aceptante'),
    SectionHeader('Comercio Exterior')
]