"""Module to list objects in an S3 bucket."""

import logging
from datetime import datetime

import boto3


def list_bucket_objects(
    bucket: str, prefix: str | list[str]
) -> list[dict[str, str | int | datetime]]:
    """
    List all objects in an S3 bucket with the given prefix. The prefix can be a string or a list of strings. The prefix
    has to either be a file, the bucket root ("") or a folder, otherwise an empty list is returned. The objects are
    returned as a list of dictionaries with the keys 'bucket', 'key', 'size' and 'last_modified'.
    :param bucket: The S3 bucket name.
    :param prefix: The S3 prefix to search within or a list of prefixes.
    :return: A list of dictionaries with the keys 'bucket', 'key', 'size' and 'last_modified'.
    """
    try:  # pylint: disable=too-many-nested-blocks
        s3_client = boto3.client("s3")
        paginator = s3_client.get_paginator("list_objects_v2")

        prefix_list = prefix if isinstance(prefix, list) else [prefix]

        objects: list[dict[str, str | int | datetime]] = []
        for pre in prefix_list:
            page_iterator = paginator.paginate(Bucket=bucket, Prefix=pre)

            if pre.endswith("/"):
                pre = pre[:-1]  # noqa: PLW2901

            for page in page_iterator:
                if "Contents" in page:
                    for obj in page["Contents"]:
                        # The listed files are either the exact prefix or a subfolder of the prefix. Not a file or
                        # folder that only starts with the same name. Otherwise a request with prefix
                        # 'research-files/suno' would also return objects from 'research-files/suno-download.py' or
                        # 'research-files/suno-tests' instead of just the files in the subfolder 'research-files/suno'.
                        key = obj["Key"]
                        if len(key) > len(pre) and key[len(pre)] != "/":
                            continue

                        objects.append(
                            {
                                "bucket": bucket,
                                "key": key,
                                "size": obj["Size"],
                                "last_modified": obj["LastModified"],
                            }
                        )

    except Exception:
        logging.exception(
            "Error occured in `list_bucket_objects()`. Called with parameters:\n"
            "  bucket: %s\n"
            "  prefix: %s",
            bucket,
            prefix,
        )
        raise

    return objects
