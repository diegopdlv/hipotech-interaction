# Data Extraction and Analysis

This repository is for the analysis of **Equifax data**. It consists of two main components:
1. **Data Extraction & Storage** – Parsing and structuring data from Equifax reports.
2. **ML Analysis** – Performing machine learning analysis on extracted data.

## **1️⃣ Checking if Git is Installed**
Before proceeding, check if Git is installed on your system. Open a terminal and run:
```sh
git --version
```
If Git is installed, you should see an output like:
```
git version 2.x.x
```
If you see an error or Git is not found, follow the installation steps below.

### **Installing Git (If Not Installed)**
1. **Download Git** from [git-scm.com](https://git-scm.com/downloads).
2. **Run the installer** and select:
   - "Use Git from the Windows Command Prompt" (recommended)
   - "Use MinTTY" or "Use Windows default console" (your choice)
3. **Finish installation** and restart your terminal.
4. Verify installation by running:
   ```sh
   git --version
   ```

---

## **2️⃣ Cloning the Repository**
To copy the repository to your local machine, open a terminal and run:
```sh
git clone https://github.com/YOUR-ORG/Data_Extraction_and_Analysis.git
cd Data_Extraction_and_Analysis
```

---

## **3️⃣ Setting Up Python 3.11 and Virtual Environments**

To ensure consistency, use a **virtual environment (venv)**:

```sh
python3.11 -m venv venv
```
Then, activate the virtual environment:

- **Windows (Command Prompt):**
  ```sh
  venv\Scripts\activate
  ```
- **Windows (PowerShell - If Activation is Blocked, Run the Fix Below):**
  ```sh
  Set-ExecutionPolicy Unrestricted -Scope Process
  venv\Scripts\Activate.ps1
  ```
- **Mac/Linux:**
  ```sh
  source venv/bin/activate
  ```

### **Installing Dependencies**
Once the virtual environment is activated, install dependencies:
```sh
pip install -r requirements.txt
```

---

## **4️⃣ Using Git Commands & Workflow**

### **Checking Which Branch You Are On**
```sh
git branch
```

### **Creating a New Branch (Before Making Changes)**
If you are working on a new feature or bug fix, create a separate branch:
```sh
git checkout -b your-feature-name
```

### **Pulling the Latest Changes (Before Working on Code)**
Always pull the latest changes before working:
```sh
git pull origin main
```

### **Committing and Pushing Changes**
Once you've made changes, save them with:
```sh
git add .
git commit -m "Description of changes"
git push origin your-feature-name
```

### **Merging Updates from Main into Your Branch**
If someone else makes changes, sync your local repo:
```sh
git checkout main
git pull origin main
git checkout your-feature-name
git merge main
```

### **Creating a Pull Request (PR)**
Once your branch is ready, open GitHub and create a **Pull Request (PR)** for review.

---

## **5️⃣ Setting Up a .gitignore File**
To avoid committing unnecessary files, add the following `.gitignore` file at the root of your project:

```
/venv           # Ignore the virtual environment folder
.gitignore      # Ignore this file itself
.idea          # Ignore PyCharm project settings (not needed in Git)
```

### **Explanation of .gitignore Entries:**
- `/venv` → Prevents committing the virtual environment, which should be created locally on each machine.
- `.gitignore` → This file tells Git which files to ignore.
- `.idea` → PyCharm project metadata; not required for collaboration.

To add this file, run:
```sh
echo "/venv\n.gitignore\n.idea" > .gitignore
```
And then commit it:
```sh
git add .gitignore
git commit -m "Add .gitignore file"
git push origin main
```

---

## **6️⃣ Common Issues & Troubleshooting**
### *pip command not found?*
Use:
```sh
python -m pip install -r requirements.txt
```

### *venv activation not working on Windows?*
Try:
```sh
Set-ExecutionPolicy Unrestricted -Scope Process
```
Then re-run:
```sh
venv\Scripts\activate
```

---

