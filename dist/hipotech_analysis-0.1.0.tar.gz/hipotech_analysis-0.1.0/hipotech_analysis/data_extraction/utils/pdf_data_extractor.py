# data_extraction_archive/pdf_extractor.py

import re
from pathlib import Path
from pdf_parser.pdf_processor import PDFTextProcessor

from .equifax_file_header_names import EQUIFAX_FILE_HEADER_NAMES
from .extract_general_score_ad_hoc import extract_experian_color_from_img

def _get_num_processes(comienza_data: PDFTextProcessor, data_dict: dict) -> list:
    title_row = f"DNI {data_dict['dni_id']} - {data_dict['name']}"
    title_row = f"Deuda Total"
    end_text = f"* La persona consultada cuenta con los siguientes créditos e indicadores."
    start_idx = 0
    end_idx = len(comienza_data.df)
    for i, row in comienza_data.df.iterrows():
       if row['text'] == title_row:
            start_idx = i
       if row['text'] == end_text:
           end_idx = i

    comienza_data.df = comienza_data.df.iloc[start_idx+1:end_idx]
    comienza_data = comienza_data[comienza_data['x0'] < 350]

    processes = []
    for i, row in comienza_data.df.iterrows():
        if (i - 1) % 5 == 0:
            processes.append(row['text'])
    return processes


def _get_basic_dni_ruc_info(comienza_data: PDFTextProcessor) -> dict:
    """
    Extract basic DNI and RUC information from the 'Comienza' section.
    """

    data_dict: dict = {}
    comienza_text = comienza_data.text().replace(',', '')

    pattern_name = r"(?:DNI|RUC)\s+\d+\s*-\s*(.+)"
    pattern_dni = r"DNI\s*\n(\d+)\s*\n([\d.]+)\s*\n([\d.]+)"
    pattern_ruc = r"RUC\s*\n(\d+)\s*\n([\d.]+)\s*\n([\d.]+)"

    match_name = re.search(pattern_name, comienza_text)
    match_dni = re.search(pattern_dni, comienza_text)
    match_ruc = re.search(pattern_ruc, comienza_text)

    data_dict['name'] = match_name.group(1).strip() if match_name else None

    if match_dni:
        data_dict['dni_id'] = match_dni.group(1)
        score = float(match_dni.group(2))
        data_dict['dni_semáforo_score'] = score
        data_dict['dni_semáforo_label'] = _label_semaforo_score(score)
        data_dict['dni_total_debt'] = float(match_dni.group(3))
    else:
        data_dict['dni_id'] = None
        data_dict['dni_semáforo_score'] = None
        data_dict['dni_semáforo_label'] = None
        data_dict['dni_total_debt'] = None

    if match_ruc:
        data_dict['ruc_id'] = match_ruc.group(1)
        score = float(match_ruc.group(2))
        data_dict['ruc_semáforo_score'] = score
        data_dict['ruc_semáforo_label'] = _label_semaforo_score(score)
        data_dict['ruc_total_debt'] = float(match_ruc.group(3))
    else:
        data_dict['ruc_id'] = None
        data_dict['ruc_semáforo_score'] = None
        data_dict['ruc_semáforo_label'] = None
        data_dict['ruc_total_debt'] = None

    return data_dict


def _get_score_and_capacity_info(sabio_data: PDFTextProcessor, pdf_file_path: Path) -> dict:
    """
    Extract Experian score, person score, and payment capacity information.
    """
    data_dict: dict = {}

    # Split the data into right and left based on the x0 value.
    data_right = sabio_data[sabio_data['x0'] > 275].reset_index(drop=True)
    data_left = sabio_data[sabio_data['x0'] <= 275].reset_index(drop=True)

    text_right = data_right.text()
    text_left = data_left.text()

    pattern_experian_score = r"Score Experian\n(\d+)"
    pattern_person_score = r"(\d+)\s+de\s+100\s+personas"
    pattern_capacity_gen = r"Capacidad de Pago Mensual"
    pattern_capacity_range = r"S/\s*(\d+(?:\.\d+)?)\s*(?:a\s*S/\s*(\d+(?:\.\d+)?))?"

    match_experian = re.search(pattern_experian_score, text_right)
    match_person = re.search(pattern_person_score, text_right.replace("\n", " "))
    match_capacity_gen = re.search(re.escape(pattern_capacity_gen), text_left)
    match_capacity_range = None

    if match_capacity_gen:
        start_idx = match_capacity_gen.end()
        remaining_text = text_left[start_idx:].strip()
        lines = remaining_text.split('\n')
        extracted_text = ' '.join(lines[:3]).replace(',', '')
        match_capacity_range = re.search(pattern_capacity_range, extracted_text)

    data_dict['experian_score'] = int(match_experian.group(1)) if match_experian else None
    data_dict['hipotech_score'] = f"{round(data_dict['experian_score'] / 100, 1)}"
    data_dict['experian_score_color'] = extract_experian_color_from_img(pdf_file_path)
    data_dict['default_risk_prob'] = int(match_person.group(1)) if match_person else None

    if match_capacity_range and match_capacity_range.group(1):
        data_dict['pay_capacity_min'] = int(float(match_capacity_range.group(1)))
        capacity_max = int(float(match_capacity_range.group(2))) if match_capacity_range.group(2) else None
        data_dict['pay_capacity_max'] = capacity_max or data_dict['pay_capacity_min']
    else:
        data_dict['pay_capacity_min'] = None
        data_dict['pay_capacity_max'] = None

    return data_dict


def extract_credit_score_data(pdf_file_path: Path) -> dict:
    """
    Process a single PDF and return a dictionary with the extracted data.
    """

    pdf_data = PDFTextProcessor.from_pdf(pdf_file_path, verbose=False)
    pdf_data.assign_sections(section_headers=EQUIFAX_FILE_HEADER_NAMES, initial_header="Comienza")

    comienza_data = pdf_data[pdf_data['section'] == 'Comienza'].reset_index(drop=True)
    sabio_data = pdf_data[pdf_data['section'] == 'Sabio Empresarial'].reset_index(drop=True)

    data_dict: dict = {}
    data_dict.update(_get_basic_dni_ruc_info(comienza_data))
    data_dict.update(_get_score_and_capacity_info(sabio_data, pdf_file_path))
    data_dict.update(_compute_property_and_payment_estimates(pay_capacity_min=data_dict["pay_capacity_min"], pay_capacity_max=data_dict["pay_capacity_max"]))
    data_dict['pdf_path'] = pdf_file_path
    return data_dict


def _label_semaforo_score(score: float | None) -> str | None:
        """
        Label the semáforo score based on specified thresholds.
        """
        if score is None:
            return None
        if 0 <= score < 0.001:
            return "Green"
        elif 0.001 <= score <= 2:
            return "Yellow"
        elif 2 < score <= 6:
            return "Red"
        else:
            return "Invalid Score"


def _label_experian_score(pdf_file_path: Path) -> str:
    color_label = extract_experian_color_from_img(pdf_file_path)
    return color_label

def _compute_property_and_payment_estimates(
    pay_capacity_min: float,
    pay_capacity_max: float,
    interest_rate: float = 0.09,
    loan_term_months: int = 240
) -> dict:
    """
    Given min and max monthly payment capacities, computes estimated property prices
    and corresponding monthly payments using standard loan formulas.

    Args:
        pay_capacity_min: Lower bound of monthly payment capacity (S/).
        pay_capacity_max: Upper bound of monthly payment capacity (S/).
        interest_rate: Annual interest rate (default 9%).
        loan_term_months: Loan term in months (default 240 months / 20 years).

    Returns:
        Dictionary with rounded property price estimates and payment values.
    """
    r = interest_rate / 12  # monthly interest rate
    n = loan_term_months

    def present_value(payment: float) -> float:
        return payment * (1 - (1 + r) ** -n) / r

    def monthly_payment(principal: float) -> float:
        return principal * (r * (1 + r) ** n) / ((1 + r) ** n - 1)

    min_price = present_value(pay_capacity_min)
    max_price = present_value(pay_capacity_max)

    min_payment = monthly_payment(min_price)
    max_payment = monthly_payment(max_price)

    return {
        "estimated_min_property_price": min_price,
        "estimated_max_property_price": max_price,
        "estimated_monthly_payment_min_price": min_payment,
        "estimated_monthly_payment_max_price": max_payment
    }


if __name__ == "__main__":
    """
    Basic Use Case
    """
    pdf_file_path = r"path/to/experian_pdf.pdf"
    pdf_file_path = r"C:\Users\gregg\Documents\HipoTek\experian_pdfs\09_june_2025\1PDF2GARCIACASTROJAVIERMANUEL40620251187.pdf"
    credit_score_data: dict = extract_credit_score_data(pdf_file_path)

    j = 7