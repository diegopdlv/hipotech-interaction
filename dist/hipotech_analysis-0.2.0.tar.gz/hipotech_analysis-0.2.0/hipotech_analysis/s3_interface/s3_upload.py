"""Module for S3 wrapper that uploads files and directories to S3."""

import logging
import multiprocessing as mp
from functools import partial
from pathlib import Path

import boto3
from tqdm.contrib.concurrent import process_map


def upload_to_bucket(
    root_path: Path | list[Path], bucket: str, prefix: str = ""
) -> list[str]:
    """
    Uploads a single or multiple local files or directories to a S3 bucket. If a directory is provided, all files in
    the directory and its subdirectories will be uploaded. The directory structure will be preserved in the S3 bucket.
    The function returns a list of S3 keys of the uploaded files.
    :param root_path: The local file or directory to upload or a list of local files or directories to upload.
    :param bucket: The S3 bucket name.
    :param prefix: The S3 prefix to upload the files to. Default is an empty string.
    :return: A list of S3 keys of the uploaded files.
    """
    try:
        files_to_upload = []
        root_path_list = root_path if isinstance(root_path, list) else [root_path]
        for rpath in root_path_list:
            if rpath.is_file():
                files_to_upload.append((rpath, rpath))
            else:
                files_to_upload += [
                    (item, rpath) for item in rpath.rglob("*") if item.is_file()
                ]
        if not files_to_upload:
            return []

        num_processes = max(1, min(len(files_to_upload), mp.cpu_count() - 1))
        if prefix and not prefix.endswith("/"):
            prefix += "/"

        upload_file_partial = partial(_upload_file, bucket=bucket, prefix=prefix)

        s3_keys = process_map(
            upload_file_partial,
            files_to_upload,
            max_workers=num_processes,
            desc=f"Uploading files to {bucket}",
        )

    except Exception:
        logging.exception(
            "Error occured in `upload_to_bucket()`. Called with parameters:\n"
            "  root_path: %s\n"
            "  bucket: %s\n"
            "  prefix: %s",
            root_path,
            bucket,
            prefix,
        )
        raise

    return s3_keys  # type: ignore[no-any-return]


def _upload_file(path_tuple: tuple[Path, Path], bucket: str, prefix: str) -> str:
    """
    Internal function to upload a file to an S3 bucket. Use `upload_to_bucket()` instead.
    :param path_tuple: A tuple containing the local file path and the root path of the file.
    :param bucket: The S3 bucket name.
    :param prefix: The S3 prefix to upload the files to.
    :return: The S3 key of the uploaded
    """
    try:
        s3_client = boto3.client("s3")
        file_path, root_path = path_tuple
        relative_path = file_path.relative_to(root_path.parent)
        s3_key = prefix + str(relative_path)

        s3_client.upload_file(file_path, bucket, s3_key)

    except Exception:
        logging.exception(
            "Error occured in `_upload_file()`. Called with parameters:\n"
            "  path_tuple: %s\n"
            "  bucket: %s\n"
            "  prefix: %s",
            path_tuple,
            bucket,
            prefix,
        )
        raise

    return s3_key
