import fitz  # PyMuPDF
import numpy as np
import cv2
from pathlib import Path

def extract_crop_color(
        pdf_path: str | Path,
        crop_box: tuple[int, int, int, int] = (1510, 665, 30, 30),
        show_debug: bool = False
) -> tuple[float, float, float]:
    """
    Extracts the average HSV values from a cropped region of the first page of a PDF.

    Args:
        pdf_path: Path to the PDF file.
        crop_box: Tuple (x, y, w, h) defining the crop region.
        show_debug: If True, displays the page with the crop box drawn.

    Returns:
        A tuple (avg_h, avg_s, avg_v) representing the mean HSV values in the cropped area.
    """
    doc = fitz.open(str(pdf_path))
    page = doc.load_page(0)  # First page
    pix = page.get_pixmap(dpi=200)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
    img_rgb = img[..., :3]  # Remove alpha if present

    x, y, w, h = crop_box
    crop = img_rgb[y:y+h, x:x+w]

    if show_debug:
        show_debug_overlay(img_rgb, crop_box)

    avg_r = np.mean(crop[:, :, 0])
    avg_g = np.mean(crop[:, :, 1])
    avg_b = np.mean(crop[:, :, 2])

    return avg_r, avg_g, avg_b


def classify_color(avg_r: float, avg_g: float, avg_b: float, max_distance: float = 40.0) -> str:
    reference_colors = {
        "red":        (255, 0, 0),
        "orange":     (253, 118, 7),
        "yellow":     (255, 191, 0),
        "green":      (146, 208, 80),
        "dark green": (0, 176, 80),
    }

    input_rgb = np.array([avg_r, avg_g, avg_b])
    distances = {
        label: np.linalg.norm(input_rgb - np.array(rgb))
        for label, rgb in reference_colors.items()
    }

    closest_label, min_distance = min(distances.items(), key=lambda x: x[1])
    if min_distance > max_distance:
        label = "unknown"
    else:
        label = closest_label

    print(avg_r, avg_g, avg_b, label, min_distance)
    return label

def show_debug_overlay(image_rgb: np.ndarray, crop_box: tuple[int, int, int, int]) -> None:
    """
    Draws a lime green box on the image and shows it using OpenCV.
    """
    debug_img = image_rgb.copy()
    x, y, w, h = crop_box
    cv2.rectangle(debug_img, (x, y), (x + w, y + h), color=(0, 255, 0), thickness=2)
    cv2.imshow("Cropped Area (Lime Green Box)", cv2.cvtColor(debug_img, cv2.COLOR_RGB2BGR))
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def extract_experian_color_from_img(pdf_path: Path | str) -> str:
    pdf_path = Path(pdf_path)
    color_rgb = extract_crop_color(pdf_path)
    color_label = classify_color(*color_rgb)
    return color_label


if __name__ == "__main__":
    from pathlib import Path

    pdf_folder = r"C:\Users\gregg\Documents\HipoTek\experian_pdfs\09_june_2025"
    # pdf_folder = r"C:\Users\gregg\Documents\HipoTek\experian_pdfs\test_small"

    folder_path = Path(pdf_folder)
    pdf_paths = list(folder_path.glob("*.pdf"))


    for pdf_path in pdf_paths:
        extract_experian_color_from_img(pdf_path)
