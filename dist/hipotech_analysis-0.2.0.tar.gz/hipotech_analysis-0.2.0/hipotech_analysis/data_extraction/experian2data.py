# data_extraction/pipeline.py

from pathlib import Path
import pandas as pd
from tqdm import tqdm

from .utils.pdf_data_extractor import extract_credit_score_data

"""
This code is design to contain the pipeline for data extraction

So from PDF --> CSV

Optionally can: return dataframe, save CSV, save EXCEL

"""


def extract_data_from_single_pdf(pdf_file_path: Path):

    credit_score_data: dict = extract_credit_score_data(pdf_file_path)
    return credit_score_data

def extract_data_from_folder(folder_path: Path, show_progress: bool = False):

    pdf_paths = list(folder_path.glob("*.pdf"))

    pdf_paths_iterator = tqdm(pdf_paths, desc="Processing PDFs") if show_progress else pdf_paths

    credit_scores_consortium = []

    for pdf_path in pdf_paths_iterator:
        credit_score_data = extract_credit_score_data(pdf_path)
        credit_scores_consortium.append(credit_score_data)

    credit_scores_df = pd.DataFrame(credit_scores_consortium)
    return credit_scores_df


if __name__ == "__main__":
    pdf_folder = r"C:\Users\gregg\Documents\HipoTek\experian_pdfs\test_small"
    pdf_folder = r"reports_july_12"
    folder_path = Path(pdf_folder)

    credit_score_df: pd.DataFrame = extract_data_from_folder(folder_path, show_progress=True)
    credit_score_df.to_csv("credit_score_data.csv", index=False)
    print(credit_score_df["experian_score_color"])


