from setuptools import setup, find_packages

setup(
    name="hipotech_analysis",
    version="0.2.0",
    include_package_data=True,
    packages=find_packages(),
    package_data={
        "hipotech_analysis": [
            "html_generation/index_template.html",
            "html_generation/images/hipotech/hipotech-logo.webp",
            "html_generation/formatting/*css",
            "html_generation/images/*/*.webp",
            "html_generation/images/*/*.png",
        ]
    },
    install_requires=[
        "pandas==2.2.3",
        "numpy==2.2.2",
        "pymupdf==1.25.2",
        "matplotlib==3.9.4",
        "scikit-learn==1.6.1",
        "playwright==1.53.0",
        "tqdm==4.67.1",
        "opencv-python==4.12.0.88",
        "awscli==1.41.4",
        "boto3==1.39.4"
    ],
    entry_points={
        'console_scripts': [
            'hipotech-cli=hipotech_analysis.main_pipeline:main',  # your CLI entrypoint function
        ],
    },
    python_requires='>=3.8',
)
