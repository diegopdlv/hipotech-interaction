from pathlib import Path
import pandas as pd
import math
from playwright.sync_api import sync_playwright
from .utils.intro_text_options import INTRO_TEXT
from .utils.io import get_relative_html_template
from tqdm import tqdm


def number_to_currency_str(number: int | float) -> str:
    """
    Format a number as currency:
    - Comma as thousands separator.
    - Dot as decimal separator.
    - Show 2 decimal places only if needed.

    Examples:
        1234       → '1,234'
        1234.5     → '1,234.50'
        1234.5678  → '1,234.57'
    """
    if isinstance(number, float) and not number.is_integer():
        return f"{number:,.2f}"
    else:
        return f"{int(number):,}"

def generate_html_report(
        data: dict,
        template_path: Path, html_output_dir: Path, pdf_output_dir: Path) -> None:
    """
    Generates an HTML report from a single row of data using a provided template.
    All placeholders in the template must match keys in the `data` dictionary.
    """

    data["dni_total_debt_str"] = number_to_currency_str(data["dni_total_debt"])
    data["ruc_total_debt_str"] = number_to_currency_str(data["ruc_total_debt"])
    data["ce_total_debt_str"] = number_to_currency_str(data["ce_total_debt"])
    
    data["pay_capacity_min_str"] = number_to_currency_str(data["pay_capacity_min"])
    data["pay_capacity_max_str"] = number_to_currency_str(data["pay_capacity_max"])
    data["estimated_min_property_price_str"] = number_to_currency_str(round(data["estimated_min_property_price"], 0))
    data["estimated_max_property_price_str"] = number_to_currency_str(round(data["estimated_max_property_price"], 0))
    data["estimated_monthly_payment_min_price_str"] = number_to_currency_str(round(data["estimated_monthly_payment_min_price"], 0))
    data["estimated_monthly_payment_max_price_str"] = number_to_currency_str(round(data["estimated_monthly_payment_max_price"], 0))

    # Read the HTML template
    html_template = get_relative_html_template(
        template_path=template_path
    )

    # Ensure output directory exists
    html_output_dir.mkdir(exist_ok=True)
    pdf_output_dir.mkdir(exist_ok=True)

    # Determine "Hipotech" color from the Experian color label
    experian_to_hippo_conversion = {
        "dark green": "green", "green": "green",
        "yellow": "yellow",
        "orange": "red", "red": "red",
        "gray": "gray",
    }

    data["hipotech_score_color"] = experian_to_hippo_conversion[data["experian_score_color"].lower()]

    # Determine Intro Text
    data['intro_text'] = INTRO_TEXT[data["hipotech_score_color"]]

    # Determine traffic light class
    data['streetlight_img_name'] = f"streetlight-{data['hipotech_score_color']}.png"

    # Determine if we are basing the report off of the DNI, C/E, or RUC
    id_type = next(
        (label for label, key in (('dni', 'dni_id'), ('ce', 'ce_id'), ('ruc', 'ruc_id')) if data.get(key)),
        'UNKNOWN'
    )

    data['relevant_id_type'] = {'dni': 'DNI', 'ce': 'C/E', 'ruc': 'RUC'}.get(id_type, 'UNKNOWN')
    data['relevant_id_value'] = data[f"{id_type}_id"]
    data['relevant_total_debt_str'] = data[f"{id_type}_total_debt_str"]

    # Fill in template using keys as-is
    html_filled = html_template
    for key, value in data.items():
        html_filled = html_filled.replace(f"{{{key}}}", str(value))

    # Generate safe filename
    id_value = data.get('dni_id') or data.get('ce_id') or data.get('ruc_id') or 'UNKNOWN'
    name = data.get('name', 'UNKNOWN')

    filename = f"Report_{id_value}_{name}.html".replace(" ", "_")
    html_output_path = html_output_dir / filename
    pdf_output_path = (pdf_output_dir / filename).with_suffix(".pdf")

    # Save the HTML version of the report
    with open(html_output_path, 'w', encoding='utf-8') as f_out:
        f_out.write(html_filled)

    # Save the PDF version of the report
    """ Note that you need to perform both `pip install playwright` and `playwright install`!"""
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(f"file://{html_output_path.resolve()}")
        content_height_px = page.evaluate("Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)")
        PX_TO_MM_RATIO, PX_BOTTOM_BUFFER = 25.4 / 96, 20
        final_page_height_mm = math.ceil(content_height_px * PX_TO_MM_RATIO + PX_BOTTOM_BUFFER)

        page.pdf(
            path=str(pdf_output_path),
            width="210mm",  # Keep a standard width of A4 (210mm)
            height=f"{final_page_height_mm}mm",
            print_background=True,
        )
        browser.close()

    # print(f"✅ Report generated: {pdf_output_path}")


#def main():
#
#    template_path = Path(r"C:\Users\gregg\PycharmProjects\HikingBook\HipoTek_Equifax_Data_Extraction_and_Analysis\html_generation\index_template.html")
#    csv_path = Path(r"C:\Users\gregg\PycharmProjects\HikingBook\HipoTek_Equifax_Data_Extraction_and_Analysis\data_extraction\credit_score_data.csv")
#    html_output_dir = Path("html_reports")
#    pdf_output_dir = Path("pdf_reports")
#
#    df = pd.read_csv(csv_path)
#
#    for _, row in tqdm(df.iterrows(), total=len(df)):
#        credit_data_dict = row.to_dict()
#        generate_html_report(row.to_dict(), template_path, html_output_dir, pdf_output_dir)
#        j = 7
#
#if __name__ == "__main__":
#    main()
