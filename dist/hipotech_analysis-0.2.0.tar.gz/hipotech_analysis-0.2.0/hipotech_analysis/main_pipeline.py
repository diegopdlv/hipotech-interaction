"""Minimal CLI interface for the Hipotech analysis pipeline."""

import argparse
from pathlib import Path
from analysis_pipeline import generate_hipotech_reports

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Minimal CLI interface for the Hipotech analysis pipeline."
    )
    parser.add_argument(
        "--sentinel_pdf_dir",
        type=str,
        default="reports_july_12",
        help="Path to the input directory containing PDF files from Sentinel.",
    )
    parser.add_argument(
        "--hipotech_reports_dir",
        type=str,
        default="hipotech_reports",
        help="Path to desired output directory for Hipotech reports.",
    )
    parser.add_argument(
        "--csv_path",
        type=str,
        default="credit_score_data.csv",
        help="Path to the desired intermediate CSV file containing credit score data.",
    )
    parser.add_argument(
        "--upload_to_s3",
        type=bool,
        default=False,
        help="Whether to upload the generated reports and data to S3. Defaults to True.",
    )
    return parser.parse_args()


def main() -> None:
    """
    Main function for the Hipotech analysis pipeline.
    
    This function orchestrates the workflow of the pipeline, which includes:
    - Extracting data from input PDF files into a CSV file.
    - Generating HTML reports and converting them to PDF files.
    - Uploading files (PDFs, CSV) to S3.
    """
    
    args = parse_arguments()

    prefixes_dict = generate_hipotech_reports(
        sentinel_reports_path=Path(args.sentinel_pdf_dir),
        hipotech_reports_path=Path(args.hipotech_reports_dir),
        csv_path=Path(args.csv_path),
        upload_to_s3=args.upload_to_s3
    )
    
    if prefixes_dict:
        print("Generated reports and data uploaded to S3:")
        for key, value in prefixes_dict.items():
            print(f"{key}: {value['bucket']}/{value['prefix']} - {value['description']}")


if __name__ == "__main__":
    main()
