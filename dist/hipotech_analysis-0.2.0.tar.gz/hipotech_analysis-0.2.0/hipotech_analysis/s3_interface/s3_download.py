"""Module for S3 wrapper that downloads files and directories from S3."""

import logging
import multiprocessing as mp
from functools import partial
from pathlib import Path

import boto3
from tqdm.contrib.concurrent import process_map

from s3_interface.s3_list import list_bucket_objects


def download_from_bucket(
    bucket: str,
    prefix: str | list[str],
    target_dir: Path,
    skip_existing_files: bool = False,
) -> None:
    """
    Downloads files or directories from an S3 bucket with the given prefix (or list of prefixes) to the target
    directory. The directory structure will be preserved in the target directory. If the target directory does not
    exist, it will be created. If `skip_existing_files` is True, existing files in the target directory will not be
    downloaded again. If prefix is a directory and ends with a '/', all files and subdirectories under the prefix will
    be downloaded and placed in target_dir. If prefix is a directory and does not end with a '/', the directory itself
    will be downloaded and placed in target_dir. This mirrors the behaviour of Unix cp and aws s3 cp commands.

    :param bucket: The S3 bucket name.
    :param prefix: The S3 prefix to download files from or a list of prefixes.
    :param target_dir: The local directory to download the files to.
    :param skip_existing_files: If True, existing files in the target directory will not be downloaded again. Default is
        False.
    """
    try:
        prefix_list = prefix if isinstance(prefix, list) else [prefix]
        prefix_objects = [
            (pre, obj)
            for pre in prefix_list
            for obj in list_bucket_objects(bucket, pre)
        ]
        if not prefix_objects:
            return
        num_processes = min(len(prefix_objects), max(1, mp.cpu_count() - 1))

        download_file_partial = partial(
            _download_file,
            bucket=bucket,
            target_dir=target_dir,
            skip_existing_files=skip_existing_files,
        )

        process_map(
            download_file_partial,
            prefix_objects,
            max_workers=num_processes,
            desc=f"Downloading files from {bucket}",
        )

    except Exception:
        logging.exception(
            "Error occurred in `download_from_bucket()`. Called with parameters:\n"
            "  bucket: %s\n"
            "  prefix: %s\n"
            "  target_dir: %s\n"
            "  skip_existing_files: %s",
            bucket,
            prefix,
            target_dir,
            skip_existing_files,
        )
        raise


def _download_file(
    prefix_obj: tuple[str, dict],
    bucket: str,
    target_dir: Path,
    skip_existing_files: bool,
) -> None:
    """
    Internal function to download a file from an S3 bucket. Use `download_from_bucket()` instead.
    :param prefix_obj: A tuple containing the prefix and the object dictionary.
    :param bucket: The S3 bucket name.
    :param target_dir: The local directory to download the files to.
    :param skip_existing_files: If True, existing files in the target directory will not be downloaded again.
    """
    try:
        prefix, obj = prefix_obj

        # Skip empty directories
        if obj["size"] == 0:
            return

        prefix = prefix[: prefix.rindex("/") + 1] if "/" in prefix else ""
        key = obj["key"]
        target_path = target_dir / key[len(prefix) :]
        target_path.parent.mkdir(parents=True, exist_ok=True)
        if skip_existing_files and target_path.exists():
            return

        s3_client = boto3.client("s3")
        s3_client.download_file(Bucket=bucket, Key=key, Filename=target_path)

    except Exception:
        logging.exception(
            "Error occured in `_download_file()`. Called with parameters:\n"
            "  prefix_obj: %s\n"
            "  bucket: %s\n"
            "  target_dir: %s\n"
            "  skip_existing_files: %s",
            prefix_obj,
            bucket,
            target_dir,
            skip_existing_files,
        )
        raise
