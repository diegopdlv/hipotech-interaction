INTRO_TEXT = {
    "green":  """
              🟢 <strong>Score Hipotech Favorable:</strong><br>
              Tu score Hipotech se encuentra en un rango favorable. Esto indica que tienes un buen historial financiero y, muy probablemente, puedes acceder a un crédito hipotecario.<br>
              Aprovecha esta oportunidad y evalúa opciones para encontrar la que mejor se adapte a ti. Nuestro equipo puede ayudarte a dar el siguiente paso hacia tu propia vivienda, <a class="styled-link" href="https://api.whatsapp.com/send/?phone=51982252421&text&type=phone_number&app_absent=0"><strong>escríbenos por WhatsApp para ver tus mejores opciones</strong></a>.
              """,
    "yellow": """
              🟡 <strong>Score Hipotech Moderado:</strong><br>
              Tu score Hipotech se encuentra en un rango moderado. Esto significa que, si bien tienes un buen manejo general de tus finanzas, hay áreas que podrían mejorarse.<br>
              Presta atención a factores como el historial de pagos y el nivel de endeudamiento. En estos casos, para poder acceder a un crédito hipotecario, te recomendamos revisar tus deudas impagadas y comenzar un programa de <strong>AhorroCasa</strong>.
              """,
    "red":    """
              🔴 <strong>Score Hipotech Bajo:</strong><br>
              Tu score Hipotech actualmente se encuentra en un rango bajo. Esto significa que, por ahora, no calificas para un crédito hipotecario, pero no te preocupes: con trabajo y seguimiento, es posible revertir esta situación.<br>
              Te recomendamos iniciar un plan de <strong>AhorroCasa</strong> y mejorar tu comportamiento financiero para aumentar tus posibilidades en el futuro. Estamos aquí para acompañarte en el proceso.
              """,
    "gray":   """
              ⚪ <strong>Score Hipotech Indefinido:</strong><br>
              No hemos podido acceder a la información necesaria para calcular tu score Hipotech. Esto puede deberse a una falta de historial o a restricciones en los datos.<br>
              Contáctate con nosotros para ayudarte a identificar los siguientes pasos. Queremos apoyarte para que puedas acceder a tu vivienda lo antes posible.
              """
}